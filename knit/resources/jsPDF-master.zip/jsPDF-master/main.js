import './jspdf';

import './main_plugins.js';
import './main_node_deps.js';
import './main_libs.js';

export default jsPDF;
